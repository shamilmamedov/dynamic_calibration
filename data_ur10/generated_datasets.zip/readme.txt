All the files whether for identification, validation or collision detection are in csv format.
Firt column is time, columns 2-7 are generalized positions, columns 8-13 are generalized
velocities, columns 14-19 are currents, columns 20-25 desired currents and columns
26-31 desired torques.




